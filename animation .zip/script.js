let tl=gsap.timeline({
  repeat:-1,
})
tl.to('.img',{
  ease:Expo.elseInout,
  duration:2,
  width:'100vh',
  stagger:'2',
},'a')
.to('.text h1',{
 ease:Expo.elseInout,
    top:'0%',
      stagger:2,
},'a')
.to('.text h1',{
 ease:Expo.elseInout,
    top:'-100%',
      stagger:2,
      delay:2,
},'a')